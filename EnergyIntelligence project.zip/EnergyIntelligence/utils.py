import numpy as np
from datetime import datetime, timedelta
from typing import List, Dict, Any, Tuple

def generate_mock_data():
    """Generate mock energy data with realistic patterns"""
    hour = datetime.now().hour
    timestamp = datetime.now()

    # Simulate solar production pattern (higher during day)
    base_production = np.sin(np.pi * (hour - 6) / 12) * 50
    production = max(0, base_production + np.random.normal(0, 5))

    # Simulate consumption pattern (business hours)
    base_consumption = 30 + 20 * np.sin(np.pi * (hour - 8) / 10)
    consumption = max(0, base_consumption + np.random.normal(0, 8))

    # Calculate efficiency and load
    efficiency = (production / (consumption + 0.1)) * 100 if consumption > 0 else 0
    current_load = consumption / 100 * 100  # Percentage of max capacity

    # Convert numpy types to Python native types
    return {
        'timestamp': timestamp,
        'energy_produced': float(production),
        'energy_consumed': float(consumption),
        'current_load': float(current_load),
        'efficiency': float(efficiency)
    }

def get_ai_recommendations(data):
    """Generate AI-powered recommendations based on current data"""
    recommendations = []

    # Analyze production vs consumption
    if data['energy_consumed'] > data['energy_produced'] * 1.2:
        recommendations.append({
            'type': 'warning',
            'message': 'High consumption detected. Consider reducing non-essential loads.'
        })

    # Analyze efficiency
    if data['efficiency'] < 60:
        recommendations.append({
            'type': 'alert',
            'message': 'Low energy efficiency detected. Check for system optimizations.'
        })

    # Analyze load patterns
    if data['current_load'] > 80:
        recommendations.append({
            'type': 'critical',
            'message': 'Peak load threshold approaching. Implement load balancing.'
        })

    return recommendations

def analyze_trends(data_points: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Analyze trends in energy data"""
    if not data_points:
        return {
            'statistics': {
                'production': {'mean': 0, 'max': 0, 'min': 0, 'std': 0},
                'consumption': {'mean': 0, 'max': 0, 'min': 0, 'std': 0}
            },
            'peak_hours': {},
            'efficiency_trend': 0,
            'peak_threshold': 0
        }

    # Convert data to numpy arrays for analysis
    timestamps = np.array([point['timestamp'] for point in data_points])
    production = np.array([point['energy_produced'] for point in data_points])
    consumption = np.array([point['energy_consumed'] for point in data_points])

    # Ensure we have valid data
    if len(production) == 0 or len(consumption) == 0:
        return {
            'statistics': {
                'production': {'mean': 0, 'max': 0, 'min': 0, 'std': 0},
                'consumption': {'mean': 0, 'max': 0, 'min': 0, 'std': 0}
            },
            'peak_hours': {},
            'efficiency_trend': 0,
            'peak_threshold': 0
        }

    # Calculate basic statistics
    stats = {
        'production': {
            'mean': float(np.mean(production)) if len(production) > 0 else 0,
            'max': float(np.max(production)) if len(production) > 0 else 0,
            'min': float(np.min(production)) if len(production) > 0 else 0,
            'std': float(np.std(production)) if len(production) > 0 else 0
        },
        'consumption': {
            'mean': float(np.mean(consumption)) if len(consumption) > 0 else 0,
            'max': float(np.max(consumption)) if len(consumption) > 0 else 0,
            'min': float(np.min(consumption)) if len(consumption) > 0 else 0,
            'std': float(np.std(consumption)) if len(consumption) > 0 else 0
        }
    }

    # Calculate peak hours (top 20% of consumption)
    if len(consumption) > 0:
        peak_threshold = float(np.percentile(consumption, 80))
        peak_hours = [point['timestamp'].hour for idx, point in enumerate(data_points) 
                     if consumption[idx] >= peak_threshold]
        peak_hours_count = {str(k): int(v) for k, v in 
                          zip(*np.unique(peak_hours, return_counts=True))} if peak_hours else {}
    else:
        peak_threshold = 0
        peak_hours_count = {}

    # Calculate efficiency trend
    efficiency_trend = float(np.mean(production - consumption)) if len(production) > 0 else 0

    return {
        'statistics': stats,
        'peak_hours': peak_hours_count,
        'efficiency_trend': efficiency_trend,
        'peak_threshold': peak_threshold
    }

def get_trend_insights(trend_data: Dict[str, Any]) -> List[Dict[str, str]]:
    """Generate insights based on trend analysis"""
    insights = []

    stats = trend_data.get('statistics', {})
    efficiency_trend = trend_data.get('efficiency_trend', 0)

    # Analyze production stability
    prod_mean = stats.get('production', {}).get('mean', 0)
    prod_std = stats.get('production', {}).get('std', 0)

    if prod_mean > 0:  # Prevent division by zero
        prod_variability = prod_std / prod_mean
        if prod_variability > 0.3:
            insights.append({
                'type': 'warning',
                'message': 'High variability in energy production detected. Consider investigating solar panel performance.'
            })

    # Analyze consumption patterns
    cons_stats = stats.get('consumption', {})
    cons_mean = cons_stats.get('mean', 0)
    cons_max = cons_stats.get('max', 0)

    if cons_mean > 0 and cons_max > cons_mean * 1.5:
        insights.append({
            'type': 'alert',
            'message': f'Significant consumption spikes detected. Peak usage is {cons_max:.1f} kWh vs average {cons_mean:.1f} kWh.'
        })

    # Efficiency trend analysis
    if efficiency_trend < -5:
        insights.append({
            'type': 'critical',
            'message': 'Declining energy efficiency trend observed. Schedule system maintenance.'
        })
    elif efficiency_trend > 5:
        insights.append({
            'type': 'success',
            'message': 'Positive energy efficiency trend. Current optimizations are working well.'
        })

    # If no insights were generated, add a default message
    if not insights:
        insights.append({
            'type': 'info',
            'message': 'Energy consumption patterns are within normal ranges.'
        })

    return insights