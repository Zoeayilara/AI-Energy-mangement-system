import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor
from datetime import datetime, timedelta

class EnergyPredictor:
    def __init__(self):
        self.model = RandomForestRegressor(n_estimators=100, random_state=42)
        self.scaler = StandardScaler()
        self.is_trained = False

    def prepare_features(self, data):
        """Convert raw data into features for prediction"""
        df = pd.DataFrame(data)
        
        # Extract time-based features
        df['hour'] = df['timestamp'].dt.hour
        df['day_of_week'] = df['timestamp'].dt.dayofweek
        
        # Create lag features
        df['prev_consumption'] = df['energy_consumed'].shift(1)
        df['prev_production'] = df['energy_produced'].shift(1)
        
        # Drop rows with NaN values
        df = df.dropna()
        
        # Select features for prediction
        feature_columns = ['hour', 'day_of_week', 'prev_consumption', 'prev_production']
        X = df[feature_columns]
        
        return X, df['energy_consumed']

    def train(self, historical_data):
        """Train the model using historical data"""
        X, y = self.prepare_features(historical_data)
        
        # Split data into training and validation sets
        X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
        
        # Scale features
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_val_scaled = self.scaler.transform(X_val)
        
        # Train model
        self.model.fit(X_train_scaled, y_train)
        self.is_trained = True
        
        # Calculate validation score
        val_score = self.model.score(X_val_scaled, y_val)
        return val_score

    def predict_next_24h(self, latest_data):
        """Predict energy consumption for the next 24 hours"""
        if not self.is_trained:
            raise ValueError("Model needs to be trained before making predictions")
            
        # Prepare initial features
        current_time = latest_data[-1]['timestamp']
        predictions = []
        
        # Create feature data for next 24 hours
        for i in range(24):
            next_time = current_time + timedelta(hours=i+1)
            features = np.array([[
                next_time.hour,
                next_time.dayofweek,
                latest_data[-1]['energy_consumed'],
                latest_data[-1]['energy_produced']
            ]])
            
            # Scale features
            features_scaled = self.scaler.transform(features)
            
            # Make prediction
            pred = self.model.predict(features_scaled)[0]
            predictions.append({
                'timestamp': next_time,
                'predicted_consumption': pred
            })
            
        return predictions

# Initialize global predictor instance
predictor = EnergyPredictor()
