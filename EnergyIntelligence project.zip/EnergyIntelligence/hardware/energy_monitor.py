from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from typing import Optional, Dict, Any
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class EnergyReading:
    timestamp: datetime
    voltage: float
    current: float
    power: float
    energy: float
    power_factor: float
    frequency: float
    raw_data: Dict[str, Any]

class EnergyMonitor(ABC):
    """Abstract base class for energy monitoring hardware interfaces"""
    
    @abstractmethod
    def connect(self) -> bool:
        """Establish connection to the monitoring hardware"""
        pass
    
    @abstractmethod
    def disconnect(self) -> None:
        """Close connection to the monitoring hardware"""
        pass
    
    @abstractmethod
    def get_reading(self) -> Optional[EnergyReading]:
        """Get current energy readings from the device"""
        pass
    
    @abstractmethod
    def is_connected(self) -> bool:
        """Check if device is currently connected"""
        pass

class MockEnergyMonitor(EnergyMonitor):
    """Mock implementation for testing and development"""
    
    def __init__(self):
        self._connected = False
        
    def connect(self) -> bool:
        self._connected = True
        logger.info("Mock energy monitor connected")
        return True
        
    def disconnect(self) -> None:
        self._connected = False
        logger.info("Mock energy monitor disconnected")
        
    def is_connected(self) -> bool:
        return self._connected
        
    def get_reading(self) -> Optional[EnergyReading]:
        if not self._connected:
            return None
            
        # Use existing mock data generation logic
        from utils import generate_mock_data
        mock_data = generate_mock_data()
        
        return EnergyReading(
            timestamp=datetime.utcnow(),
            voltage=220.0,
            current=mock_data['energy_consumed'] / 220.0,  # Calculate from power
            power=mock_data['energy_consumed'] * 1000,  # Convert kW to W
            energy=mock_data['energy_produced'],
            power_factor=0.95,
            frequency=50.0,
            raw_data=mock_data
        )
